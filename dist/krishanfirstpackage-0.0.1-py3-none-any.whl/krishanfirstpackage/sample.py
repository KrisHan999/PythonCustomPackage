def print_sample():
    print('This is a sample output')